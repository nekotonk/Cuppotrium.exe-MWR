cuppotrium.exe

C++ GDI Malware made for educational purposes only.
It means (Windows Formatted) in reverse.
Works in Windows XP - 11
This is (not) my last malware, but i'm taking a small break from making malwares for now
You need Visual C++ runtime 2015 (x86) to make it work (because i forgot to change the runtime "Multi-Threaded DLL" to "Multi-Threaded") (this is fixed in the updated version)